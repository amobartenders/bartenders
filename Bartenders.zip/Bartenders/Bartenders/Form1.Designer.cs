﻿namespace Bartenders
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.adminBtn = new System.Windows.Forms.Button();
            this.imgBox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.naamLabel = new System.Windows.Forms.Label();
            this.prijsLabel = new System.Windows.Forms.Label();
            this.prijsLabel1 = new System.Windows.Forms.Label();
            this.naamLabel1 = new System.Windows.Forms.Label();
            this.imgBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.prijsLabel2 = new System.Windows.Forms.Label();
            this.naamLabel2 = new System.Windows.Forms.Label();
            this.imgBox2 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.prijsLabel3 = new System.Windows.Forms.Label();
            this.naamLabel3 = new System.Windows.Forms.Label();
            this.imgBox3 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.prijsLabel4 = new System.Windows.Forms.Label();
            this.naamLabel4 = new System.Windows.Forms.Label();
            this.imgBox4 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.prijsLabel5 = new System.Windows.Forms.Label();
            this.naamLabel5 = new System.Windows.Forms.Label();
            this.imgBox5 = new System.Windows.Forms.PictureBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // adminBtn
            // 
            this.adminBtn.Location = new System.Drawing.Point(876, 12);
            this.adminBtn.Name = "adminBtn";
            this.adminBtn.Size = new System.Drawing.Size(89, 32);
            this.adminBtn.TabIndex = 0;
            this.adminBtn.Text = "Login";
            this.adminBtn.UseVisualStyleBackColor = true;
            this.adminBtn.Click += new System.EventHandler(this.adminBtn_Click);
            // 
            // imgBox
            // 
            this.imgBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgBox.Location = new System.Drawing.Point(97, 116);
            this.imgBox.Name = "imgBox";
            this.imgBox.Size = new System.Drawing.Size(126, 120);
            this.imgBox.TabIndex = 12;
            this.imgBox.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Foto:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Prijs:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Naam:";
            // 
            // naamLabel
            // 
            this.naamLabel.AutoSize = true;
            this.naamLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naamLabel.Location = new System.Drawing.Point(131, 24);
            this.naamLabel.Name = "naamLabel";
            this.naamLabel.Size = new System.Drawing.Size(45, 16);
            this.naamLabel.TabIndex = 13;
            this.naamLabel.Text = "label4";
            // 
            // prijsLabel
            // 
            this.prijsLabel.AutoSize = true;
            this.prijsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijsLabel.Location = new System.Drawing.Point(131, 72);
            this.prijsLabel.Name = "prijsLabel";
            this.prijsLabel.Size = new System.Drawing.Size(45, 16);
            this.prijsLabel.TabIndex = 14;
            this.prijsLabel.Text = "label5";
            // 
            // prijsLabel1
            // 
            this.prijsLabel1.AutoSize = true;
            this.prijsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijsLabel1.Location = new System.Drawing.Point(427, 76);
            this.prijsLabel1.Name = "prijsLabel1";
            this.prijsLabel1.Size = new System.Drawing.Size(45, 16);
            this.prijsLabel1.TabIndex = 20;
            this.prijsLabel1.Text = "label5";
            // 
            // naamLabel1
            // 
            this.naamLabel1.AutoSize = true;
            this.naamLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naamLabel1.Location = new System.Drawing.Point(427, 28);
            this.naamLabel1.Name = "naamLabel1";
            this.naamLabel1.Size = new System.Drawing.Size(45, 16);
            this.naamLabel1.TabIndex = 19;
            this.naamLabel1.Text = "label4";
            // 
            // imgBox1
            // 
            this.imgBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgBox1.Location = new System.Drawing.Point(393, 120);
            this.imgBox1.Name = "imgBox1";
            this.imgBox1.Size = new System.Drawing.Size(126, 120);
            this.imgBox1.TabIndex = 18;
            this.imgBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(334, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Foto:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(334, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Prijs:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(334, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 16);
            this.label8.TabIndex = 15;
            this.label8.Text = "Naam:";
            // 
            // prijsLabel2
            // 
            this.prijsLabel2.AutoSize = true;
            this.prijsLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijsLabel2.Location = new System.Drawing.Point(734, 76);
            this.prijsLabel2.Name = "prijsLabel2";
            this.prijsLabel2.Size = new System.Drawing.Size(45, 16);
            this.prijsLabel2.TabIndex = 26;
            this.prijsLabel2.Text = "label5";
            // 
            // naamLabel2
            // 
            this.naamLabel2.AutoSize = true;
            this.naamLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naamLabel2.Location = new System.Drawing.Point(734, 28);
            this.naamLabel2.Name = "naamLabel2";
            this.naamLabel2.Size = new System.Drawing.Size(45, 16);
            this.naamLabel2.TabIndex = 25;
            this.naamLabel2.Text = "label4";
            // 
            // imgBox2
            // 
            this.imgBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgBox2.Location = new System.Drawing.Point(700, 120);
            this.imgBox2.Name = "imgBox2";
            this.imgBox2.Size = new System.Drawing.Size(126, 120);
            this.imgBox2.TabIndex = 24;
            this.imgBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(641, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 16);
            this.label11.TabIndex = 23;
            this.label11.Text = "Foto:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(641, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 16);
            this.label12.TabIndex = 22;
            this.label12.Text = "Prijs:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(641, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 16);
            this.label13.TabIndex = 21;
            this.label13.Text = "Naam:";
            // 
            // prijsLabel3
            // 
            this.prijsLabel3.AutoSize = true;
            this.prijsLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijsLabel3.Location = new System.Drawing.Point(131, 374);
            this.prijsLabel3.Name = "prijsLabel3";
            this.prijsLabel3.Size = new System.Drawing.Size(45, 16);
            this.prijsLabel3.TabIndex = 32;
            this.prijsLabel3.Text = "label5";
            // 
            // naamLabel3
            // 
            this.naamLabel3.AutoSize = true;
            this.naamLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naamLabel3.Location = new System.Drawing.Point(131, 326);
            this.naamLabel3.Name = "naamLabel3";
            this.naamLabel3.Size = new System.Drawing.Size(45, 16);
            this.naamLabel3.TabIndex = 31;
            this.naamLabel3.Text = "label4";
            // 
            // imgBox3
            // 
            this.imgBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgBox3.Location = new System.Drawing.Point(97, 418);
            this.imgBox3.Name = "imgBox3";
            this.imgBox3.Size = new System.Drawing.Size(126, 120);
            this.imgBox3.TabIndex = 30;
            this.imgBox3.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(38, 418);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 29;
            this.label16.Text = "Foto:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(38, 374);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 28;
            this.label17.Text = "Prijs:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(38, 326);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 16);
            this.label18.TabIndex = 27;
            this.label18.Text = "Naam:";
            // 
            // prijsLabel4
            // 
            this.prijsLabel4.AutoSize = true;
            this.prijsLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijsLabel4.Location = new System.Drawing.Point(427, 374);
            this.prijsLabel4.Name = "prijsLabel4";
            this.prijsLabel4.Size = new System.Drawing.Size(45, 16);
            this.prijsLabel4.TabIndex = 38;
            this.prijsLabel4.Text = "label5";
            // 
            // naamLabel4
            // 
            this.naamLabel4.AutoSize = true;
            this.naamLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naamLabel4.Location = new System.Drawing.Point(427, 326);
            this.naamLabel4.Name = "naamLabel4";
            this.naamLabel4.Size = new System.Drawing.Size(45, 16);
            this.naamLabel4.TabIndex = 37;
            this.naamLabel4.Text = "label4";
            // 
            // imgBox4
            // 
            this.imgBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgBox4.Location = new System.Drawing.Point(393, 418);
            this.imgBox4.Name = "imgBox4";
            this.imgBox4.Size = new System.Drawing.Size(126, 120);
            this.imgBox4.TabIndex = 36;
            this.imgBox4.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(334, 418);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 16);
            this.label21.TabIndex = 35;
            this.label21.Text = "Foto:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(334, 374);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 16);
            this.label22.TabIndex = 34;
            this.label22.Text = "Prijs:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(334, 326);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 16);
            this.label23.TabIndex = 33;
            this.label23.Text = "Naam:";
            // 
            // prijsLabel5
            // 
            this.prijsLabel5.AutoSize = true;
            this.prijsLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prijsLabel5.Location = new System.Drawing.Point(734, 374);
            this.prijsLabel5.Name = "prijsLabel5";
            this.prijsLabel5.Size = new System.Drawing.Size(45, 16);
            this.prijsLabel5.TabIndex = 44;
            this.prijsLabel5.Text = "label5";
            // 
            // naamLabel5
            // 
            this.naamLabel5.AutoSize = true;
            this.naamLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.naamLabel5.Location = new System.Drawing.Point(734, 326);
            this.naamLabel5.Name = "naamLabel5";
            this.naamLabel5.Size = new System.Drawing.Size(45, 16);
            this.naamLabel5.TabIndex = 43;
            this.naamLabel5.Text = "label4";
            // 
            // imgBox5
            // 
            this.imgBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgBox5.Location = new System.Drawing.Point(700, 418);
            this.imgBox5.Name = "imgBox5";
            this.imgBox5.Size = new System.Drawing.Size(126, 120);
            this.imgBox5.TabIndex = 42;
            this.imgBox5.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(641, 418);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(43, 16);
            this.label26.TabIndex = 41;
            this.label26.Text = "Foto:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(641, 374);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(43, 16);
            this.label27.TabIndex = 40;
            this.label27.Text = "Prijs:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(641, 326);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 16);
            this.label28.TabIndex = 39;
            this.label28.Text = "Naam:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 643);
            this.Controls.Add(this.prijsLabel5);
            this.Controls.Add(this.naamLabel5);
            this.Controls.Add(this.imgBox5);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.prijsLabel4);
            this.Controls.Add(this.naamLabel4);
            this.Controls.Add(this.imgBox4);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.prijsLabel3);
            this.Controls.Add(this.naamLabel3);
            this.Controls.Add(this.imgBox3);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.prijsLabel2);
            this.Controls.Add(this.naamLabel2);
            this.Controls.Add(this.imgBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.prijsLabel1);
            this.Controls.Add(this.naamLabel1);
            this.Controls.Add(this.imgBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.prijsLabel);
            this.Controls.Add(this.naamLabel);
            this.Controls.Add(this.imgBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.adminBtn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Interface";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button adminBtn;
        private System.Windows.Forms.PictureBox imgBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label naamLabel;
        private System.Windows.Forms.Label prijsLabel;
        private System.Windows.Forms.Label prijsLabel1;
        private System.Windows.Forms.Label naamLabel1;
        private System.Windows.Forms.PictureBox imgBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label prijsLabel2;
        private System.Windows.Forms.Label naamLabel2;
        private System.Windows.Forms.PictureBox imgBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label prijsLabel3;
        private System.Windows.Forms.Label naamLabel3;
        private System.Windows.Forms.PictureBox imgBox3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label prijsLabel4;
        private System.Windows.Forms.Label naamLabel4;
        private System.Windows.Forms.PictureBox imgBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label prijsLabel5;
        private System.Windows.Forms.Label naamLabel5;
        private System.Windows.Forms.PictureBox imgBox5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
    }
}

